import { Component } from '@angular/core';
import { Observable, of } from 'rxjs';

@Component({
  selector: 'app-cold-observable-demo',
  templateUrl: './cold-observable-demo.component.html',
  styleUrls: ['./cold-observable-demo.component.css']
})
export class ColdObservableDemoComponent {
  obs1$ = of(1, 2, 3, 4,5);

  obs$ = new Observable(observer => {
    console.log("Cold Observable starts");
    observer.next("1");
    observer.next("2");
    observer.next("3");
    observer.next("4");
    observer.next("5");
  });


  ngOnInit() {
    //observer -> get the values
    //comment this and check - no o/p will be displayed
    this.obs$.subscribe(val => {
      console.log(val);
    });
  }
}
