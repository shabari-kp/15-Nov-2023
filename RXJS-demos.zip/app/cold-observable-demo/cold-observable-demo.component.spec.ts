import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ColdObservableDemoComponent } from './cold-observable-demo.component';

describe('ColdObservableDemoComponent', () => {
  let component: ColdObservableDemoComponent;
  let fixture: ComponentFixture<ColdObservableDemoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ColdObservableDemoComponent]
    });
    fixture = TestBed.createComponent(ColdObservableDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
