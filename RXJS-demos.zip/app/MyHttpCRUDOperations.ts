import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable()
export class MyHTTPOps
{
    url: string;
    constructor(private hc:HttpClient)
    {
        this.url = "https://jsonplaceholder.typicode.com";
    }
   getAllData() 
   {
    let endPoints="/todos";
    this.hc.get(this.url+endPoints).subscribe(data => {
        console.log(JSON.stringify(data));
      });
   }

   getDataByID(x:number) {

    //let id: number = 1;
    let endPoints = "/posts/" + x;
    this.hc.get(this.url + endPoints).subscribe(data => {
        console.log(data);
      });
   }

   createNewData(){}

   updateData() {}

   deleteData(){}

}