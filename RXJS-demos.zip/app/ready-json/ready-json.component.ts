import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Subscription } from 'rxjs';
import {OnDestroy} from '@angular/core';

@Component({
  selector: 'app-ready-json',
  templateUrl: './ready-json.component.html',
  styleUrls: ['./ready-json.component.css']
})
export class ReadyJsonComponent implements OnDestroy
{

   result:any;
   subscription: Subscription;
  constructor(private hc:HttpClient)
  {

  }

  ngOnInit() 
  {
    this.subscription=this.hc.get("assets/friends.json")
             .subscribe((data:any) => 
               {
                this.result=data;
               }
);


  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe(); // deallocation 
  }



}
