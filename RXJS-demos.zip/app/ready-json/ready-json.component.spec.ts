import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReadyJsonComponent } from './ready-json.component';

describe('ReadyJsonComponent', () => {
  let component: ReadyJsonComponent;
  let fixture: ComponentFixture<ReadyJsonComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ReadyJsonComponent]
    });
    fixture = TestBed.createComponent(ReadyJsonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
