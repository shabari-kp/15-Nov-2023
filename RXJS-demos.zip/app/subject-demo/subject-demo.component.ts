import { Component } from '@angular/core';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-subject-demo',
  templateUrl: './subject-demo.component.html',
  styleUrls: ['./subject-demo.component.css']
})
export class SubjectDemoComponent {
  subject$ = new Subject();

  //as a sender -> emit the values

  ngOnInit() {
    
    //as a reciever 
    console.log("Recieve the values");
    this.subject$.subscribe(val => {
      console.log(val);
    });
//as a sender 
console.log("Emitting the values");
    this.subject$.next("1"); // emit 1
    this.subject$.next("2"); // emmit 2
    this.subject$.complete(); // stop emitting


    
 
   
  }

}
