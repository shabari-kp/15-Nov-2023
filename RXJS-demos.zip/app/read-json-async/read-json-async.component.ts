import { HttpBackend, HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-read-json-async',
  templateUrl: './read-json-async.component.html',
  styleUrls: ['./read-json-async.component.css']
})
export class ReadJsonAsyncComponent {
  result:any;
  constructor(private hc:HttpClient) 
  {

  }
  ngOnInit()
  {
    this.result=this.hc.get("assets/friends.json");
  }
}
