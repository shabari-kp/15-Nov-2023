import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReadJsonAsyncComponent } from './read-json-async.component';

describe('ReadJsonAsyncComponent', () => {
  let component: ReadJsonAsyncComponent;
  let fixture: ComponentFixture<ReadJsonAsyncComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ReadJsonAsyncComponent]
    });
    fixture = TestBed.createComponent(ReadJsonAsyncComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
