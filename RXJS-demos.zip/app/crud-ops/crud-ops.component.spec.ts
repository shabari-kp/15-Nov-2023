import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CRUDOPSComponent } from './crud-ops.component';

describe('CRUDOPSComponent', () => {
  let component: CRUDOPSComponent;
  let fixture: ComponentFixture<CRUDOPSComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CRUDOPSComponent]
    });
    fixture = TestBed.createComponent(CRUDOPSComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
