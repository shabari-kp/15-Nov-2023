import { Component } from '@angular/core';
import { MyHTTPOps } from '../MyHttpCRUDOperations';

@Component({
  selector: 'app-crud-ops',
  templateUrl: './crud-ops.component.html',
  styleUrls: ['./crud-ops.component.css']
})
export class CRUDOPSComponent {
constructor(private x:MyHTTPOps)
    {

    }

    getAllRecordsfromExternalSite()
    {
     this.x.getAllData();
    }
   

    getDataFromID(x:number)
    {
     this.x.getDataByID(x);
    }
  }
