import { Component } from '@angular/core';
import { Subscription, interval, take } from 'rxjs';

@Component({
  selector: 'app-observer-observable-demos',
  templateUrl: './observer-observable-demos.component.html',
  styleUrls: ['./observer-observable-demos.component.css']
})
export class ObserverObservableDemosComponent {
  mySubscription :Subscription;
  ngOnInit()
  {
   // Creating an observable - it generates number for every 2 seconds
   //emit values till you say stop
   const myNums = interval(2000);

/*
  myNums.subscribe((result: number) => 
  {
        console.log(result);
      });
*/


// take only first 6 values

const takeSixNumbers = myNums.pipe(take(6));

this.mySubscription=takeSixNumbers.subscribe((x: number) => {
  console.log(x);
},undefined,()=>{console.log("subscription completed")});


  }
}
