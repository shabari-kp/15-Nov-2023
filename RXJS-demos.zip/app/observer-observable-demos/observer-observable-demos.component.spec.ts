import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ObserverObservableDemosComponent } from './observer-observable-demos.component';

describe('ObserverObservableDemosComponent', () => {
  let component: ObserverObservableDemosComponent;
  let fixture: ComponentFixture<ObserverObservableDemosComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ObserverObservableDemosComponent]
    });
    fixture = TestBed.createComponent(ObserverObservableDemosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
