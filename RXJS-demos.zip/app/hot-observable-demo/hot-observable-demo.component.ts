import { Component } from '@angular/core';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-hot-observable-demo',
  templateUrl: './hot-observable-demo.component.html',
  styleUrls: ['./hot-observable-demo.component.css']
})
export class HotObservableDemoComponent {
  subject$ = new Subject();

  ngOnInit() {
        
    console.log("observable started emitting values");
    

  this.subject$.next("1");

  this.subject$.next("2");
  
  console.log("but there are no subscribers");
  
  console.log("consumer subscribed now");
  this.subject$.subscribe(val => {
    console.log(val);
  });

  this.subject$.next("3");
  this.subject$.complete();

}
 
}
