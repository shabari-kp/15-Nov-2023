import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HotObservableDemoComponent } from './hot-observable-demo.component';

describe('HotObservableDemoComponent', () => {
  let component: HotObservableDemoComponent;
  let fixture: ComponentFixture<HotObservableDemoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HotObservableDemoComponent]
    });
    fixture = TestBed.createComponent(HotObservableDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
