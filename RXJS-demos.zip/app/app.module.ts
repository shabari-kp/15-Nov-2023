import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HotObservableDemoComponent } from './hot-observable-demo/hot-observable-demo.component';
import { ColdObservableDemoComponent } from './cold-observable-demo/cold-observable-demo.component';
import { SubjectDemoComponent } from './subject-demo/subject-demo.component';
import { ObserverObservableDemosComponent } from './observer-observable-demos/observer-observable-demos.component';
import { ReadyJsonComponent } from './ready-json/ready-json.component';

import {HttpClientModule} from '@angular/common/http';
import { ReadJsonAsyncComponent } from './read-json-async/read-json-async.component';
import { CRUDOPSComponent } from './crud-ops/crud-ops.component';
import { MyHTTPOps } from './MyHttpCRUDOperations';

@NgModule({
  declarations: [
    AppComponent,
    HotObservableDemoComponent,
    ColdObservableDemoComponent,
    SubjectDemoComponent,
    ObserverObservableDemosComponent,
    ReadyJsonComponent,
    ReadJsonAsyncComponent,
    CRUDOPSComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [MyHTTPOps],
  bootstrap: [AppComponent]
})
export class AppModule { }
